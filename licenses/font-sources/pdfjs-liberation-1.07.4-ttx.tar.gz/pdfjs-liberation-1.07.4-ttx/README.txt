PDF.js Liberation Sans 1.07.4 — editable sources
================================================

These full TTX XML files describe the four actual fonts distributed in
pdfjs-dist 6.4.299. They retain glyph order, outlines, composite references,
TrueType instructions, font-wide hinting, metrics, character maps, naming,
and OpenType layout tables. The original copyright and license remain in
force; see LICENSE.txt (GPLv2 with the Liberation font exceptions).
Squeeze PDF does not modify the distributed font binaries.

The adjacent liberation-fonts-1.07.4.tar.gz is the complete, unmodified
upstream SFD source release, including FontForge build scripts, Makefile,
COPYING, License.txt, AUTHORS and README. Its binary release contains a few
additional alternate glyphs, compared with the PDF.js fonts; retained glyph
outlines, metrics and instructions have been checked against that release.
Do not assume that equal version numbers mean identical font binaries.

The TTX files are an additional editable representation of the exact PDF.js
fonts, exported with FontTools 4.66.1. To rebuild them:

    python3 -m venv font-build
    font-build/bin/python -m pip install -r requirements.txt
    font-build/bin/python rebuild.py rebuilt

On Windows use font-build\Scripts\python.exe instead. FontTools is a build
tool only, and is not a runtime dependency of Squeeze PDF. Its MIT-licensed
source is at https://github.com/fonttools/fonttools . The compiler may change
table packing, checksums, and padding; bit-identical TTF reconstruction is
not promised. All supplied source files may be inspected and modified under
the font license. The application continues to distribute the existing PDF.js
font bytes, not these locally rebuilt fonts.

PDF.js font provenance and glyph-order constraints:
https://github.com/mozilla/pdf.js/blob/v6.4.299/external/standard_fonts/README.md
Upstream SFD source:
https://releases.pagure.org/liberation-fonts/liberation-fonts-1.07.4.tar.gz
