#!/usr/bin/env python3
"""Rebuild editable PDF.js Liberation font sources. Requires FontTools 4.66.1."""
from pathlib import Path
import argparse
from fontTools.ttLib import TTFont
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("output", type=Path)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
for source in sorted(Path(__file__).parent.glob("*.ttx")):
    font = TTFont(recalcTimestamp=False, recalcBBoxes=False)
    font.importXML(source)
    # Preserve the historical range recorded in the editable source.
    # FontTools otherwise changes usFirstCharIndex from 33 to 32.
    font["OS/2"].updateFirstAndLastCharIndex = lambda _font: None
    font.save(args.output / source.with_suffix(".ttf").name)
